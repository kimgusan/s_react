function Price() {
    return <h1>Price</h1>;
}
export default Price;
